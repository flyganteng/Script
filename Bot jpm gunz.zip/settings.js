require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6283185416971"
global.namaowner = "Natamiku"
global.namaowner2 = "Natami"

//======== Setting Bot & Link ========//
global.namabot = "𝑿𝒚𝒑𝒉𝒐𝒓𝒖𝒔c" 
global.namabot2 = "𝑿𝒚𝒑𝒉𝒐𝒓𝒖𝒔c"
global.version = "v1.0.0"
global.foother = "Created By Natami Bot"

global.linkgc = ''
global.linksaluran = ""
global.linkyt = 'https://www.youtube.com/@flyhikari'
global.linktele = "https://t.me/nataxmiku"
global.web = "Natami"

global.packname = "Created By Natami Bot"
global.author = ""

global.namach = ""
global.idch = ""

//========== Setting Event ==========//
global.autoread = false
global.anticall = false
global.autoreadsw = false

//==== Waktu Jeda Jpm & Pushkon ====//
global.delaypushkontak = 4500
global.delayjpm = 5000

//========== Setting Foto ===========//
global.thumb = "https://files.catbox.moe/t5m5ul.jpg"
global.img = "https://files.catbox.moe/t5m5ul.jpg"
global.thumbxm = "https://files.catbox.moe/t5m5ul.jpg"
global.thumbbc = "https://files.catbox.moe/t5m5ul.jpg"

//========= Setting Payment =========//
//Kalo Gak Ada Isi Aja jadi false
global.dana = "081313460663"
global.gopay = "081313460663"
global.ovo = false
global.qris = false

//========= Setting Payment =========// 
global.namadana = "Natami Pay"
global.namagopay = "L*l* Lub"
global.namaovo = "L*l* Lub" 

//========= Setting Message =========//
global.msg = {
"error": "Error terjasi kesalahan",
"done": "Bueress Omm", 
"wait": "Loading. . .", 
"group": "*• Group Only* This Feature Is Only For Within Groups!", 
"private": "*• Private Chat* This Feature Is Only For Within Groups!", 
"owner": "*• Owner Only* This feature is only for Bot Owners!", 
"developer": "*• Developer Only* This Feature Is For Developers Only"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})